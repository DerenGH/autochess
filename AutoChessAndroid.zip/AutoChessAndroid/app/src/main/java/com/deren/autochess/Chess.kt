package com.deren.autochess

object Chess {
    fun sqIdx(name: String): Int = (8 - (name[1] - '0')) * 8 + ("abcdefgh".indexOf(name[0]))
    fun sqName(i: Int): String = "abcdefgh"[i and 7].toString() + (8 - (i shr 3))
    fun isWhite(c: Char) = c != '.' && c.isUpperCase()

    fun attacked(b: CharArray, sq: Int, by: Char): Boolean {
        val r = sq shr 3
        val c = sq and 7
        val w = by == 'w'
        fun at(rr: Int, cc: Int): Char = if (rr in 0..7 && cc in 0..7) b[rr * 8 + cc] else '.'
        val pr = if (w) r + 1 else r - 1
        for (dc in intArrayOf(-1, 1)) if (at(pr, c + dc) == (if (w) 'P' else 'p')) return true
        val kn = arrayOf(intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
            intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1))
        for (d in kn) if (at(r + d[0], c + d[1]) == (if (w) 'N' else 'n')) return true
        for (dr in -1..1) for (dc in -1..1) if ((dr != 0 || dc != 0) && at(r + dr, c + dc) == (if (w) 'K' else 'k')) return true
        fun ray(dirs: Array<IntArray>, a: Char, q: Char): Boolean {
            for (d in dirs) {
                var rr = r + d[0]
                var cc = c + d[1]
                while (rr in 0..7 && cc in 0..7) {
                    val p = b[rr * 8 + cc]
                    if (p != '.') { if (p == a || p == q) return true; break }
                    rr += d[0]; cc += d[1]
                }
            }
            return false
        }
        val straight = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
        val diag = arrayOf(intArrayOf(1, 1), intArrayOf(1, -1), intArrayOf(-1, 1), intArrayOf(-1, -1))
        if (ray(straight, if (w) 'R' else 'r', if (w) 'Q' else 'q')) return true
        if (ray(diag, if (w) 'B' else 'b', if (w) 'Q' else 'q')) return true
        return false
    }

    fun kings(b: CharArray): Pair<Int, Int> = Pair(b.count { it == 'K' }, b.count { it == 'k' })

    /** True when the position can be handed to the engine. */
    fun sane(b: CharArray): Boolean {
        val (kw, kb) = kings(b)
        if (kw != 1 || kb != 1) return false
        for (i in 0 until 8) {
            if (b[i] == 'P' || b[i] == 'p' || b[56 + i] == 'P' || b[56 + i] == 'p') return false
        }
        return true
    }

    fun castlingPossible(b: CharArray): String {
        val sb = StringBuilder()
        if (b[60] == 'K' && b[63] == 'R') sb.append('K')
        if (b[60] == 'K' && b[56] == 'R') sb.append('Q')
        if (b[4] == 'k' && b[7] == 'r') sb.append('k')
        if (b[4] == 'k' && b[0] == 'r') sb.append('q')
        return sb.toString()
    }

    /** Which colour just moved, judged from the squares that were emptied. Null if unclear. */
    fun mover(prev: CharArray, cur: CharArray): Char? {
        var w = 0
        var b = 0
        for (i in 0 until 64) {
            if (prev[i] != '.' && cur[i] == '.') { if (isWhite(prev[i])) w++ else b++ }
        }
        return when {
            w > 0 && b == 0 -> 'w'
            b > 0 && w == 0 -> 'b'
            else -> null
        }
    }

    /** En passant target if the mover just pushed a pawn two squares. */
    fun epTarget(prev: CharArray, cur: CharArray, mover: Char): String {
        val pawn = if (mover == 'w') 'P' else 'p'
        for (file in 0 until 8) {
            if (mover == 'w' && prev[48 + file] == pawn && cur[48 + file] == '.' && cur[32 + file] == pawn && prev[32 + file] == '.')
                return sqName(40 + file)
            if (mover == 'b' && prev[8 + file] == pawn && cur[8 + file] == '.' && cur[24 + file] == pawn && prev[24 + file] == '.')
                return sqName(16 + file)
        }
        return "-"
    }

    fun fen(b: CharArray, stm: Char, castle: String, ep: String): String {
        val sb = StringBuilder()
        for (r in 0 until 8) {
            var e = 0
            for (c in 0 until 8) {
                val p = b[r * 8 + c]
                if (p == '.') e++ else { if (e > 0) { sb.append(e); e = 0 }; sb.append(p) }
            }
            if (e > 0) sb.append(e)
            if (r < 7) sb.append('/')
        }
        return sb.toString() + " " + stm + " " + (if (castle.isEmpty()) "-" else castle) + " " + ep + " 0 1"
    }

    /** True if the side to move can capture the other king (wrong side to move). */
    fun wrongSide(b: CharArray, stm: Char): Boolean {
        val idle = if (stm == 'w') 'b' else 'w'
        val ik = b.indexOf(if (idle == 'w') 'K' else 'k')
        return attacked(b, ik, stm)
    }
}
