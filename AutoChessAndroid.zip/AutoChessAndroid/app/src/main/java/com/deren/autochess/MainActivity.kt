package com.deren.autochess

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("ac", Context.MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(36), dp(20), dp(24))
        col.setBackgroundColor(Color.rgb(13, 17, 21))

        fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = size
            v.setTextColor(color)
            if (bold) v.setTypeface(v.typeface, android.graphics.Typeface.BOLD)
            v.setPadding(0, dp(6), 0, dp(6))
            return v
        }

        col.addView(text("AutoChess", 28f, Color.WHITE, true))
        col.addView(text(
            "Shows the best move as two coloured frames on top of your chess app. " +
                "Orange frame: the piece to move. Green frame: where it goes.\n\n" +
                "1. Tap Start and allow screen capture.\n" +
                "2. Open your chess game. The panel at the top of the screen shows what it is doing.\n" +
                "3. If the frames sit in the wrong place, tap Board and drag the two rings onto the board corners.",
            14f, Color.rgb(170, 184, 197)))

        val skillLab = text("", 14f, Color.WHITE)
        val skill = SeekBar(this)
        skill.max = 20
        skill.progress = prefs.getInt("skill", 20)
        fun skillText() { skillLab.text = "Strength: level ${skill.progress}" + (if (skill.progress == 20) " (full)" else "") }
        skillText()
        skill.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { prefs.edit().putInt("skill", p).apply(); skillText() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(skillLab)
        col.addView(skill)

        val timeLab = text("", 14f, Color.WHITE)
        val time = SeekBar(this)
        time.max = 9
        time.progress = (prefs.getInt("time", 2000) / 1000 - 1).coerceIn(0, 9)
        fun timeText() { timeLab.text = "Thinking time: ${time.progress + 1} s per move" }
        timeText()
        time.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { prefs.edit().putInt("time", (p + 1) * 1000).apply(); timeText() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(timeLab)
        col.addView(time)

        val start = Button(this)
        start.text = "Start"
        start.textSize = 18f
        start.setOnClickListener { start() }
        col.addView(start, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)).apply { topMargin = dp(24) })

        val stop = Button(this)
        stop.text = "Stop"
        stop.setOnClickListener {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        }
        col.addView(stop, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(8) })

        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.rgb(13, 17, 21))
        sv.addView(col)
        setContentView(sv)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\" for AutoChess, then tap Start again.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data)
                startForegroundService(i)
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "Screen capture was not allowed.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
