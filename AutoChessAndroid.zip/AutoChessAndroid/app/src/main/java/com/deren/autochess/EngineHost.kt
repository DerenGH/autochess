package com.deren.autochess

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/**
 * Runs Stockfish 18 (WebAssembly build) inside a hidden 1x1 WebView and talks UCI to it.
 * The engine page is assets/engine.html.
 */
class EngineHost(
    private val ctx: Context,
    private val wm: WindowManager,
    private val onLine: (String) -> Unit,
    private val onLoaded: () -> Unit
) {
    private var web: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    fun start() {
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
            .build()
        val w = WebView(ctx)
        w.settings.javaScriptEnabled = true
        w.settings.allowFileAccess = false
        w.addJavascriptInterface(Bridge(), "Android")
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView, url: String) {
                onLoaded()
            }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            1, 1, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        wm.addView(w, lp)
        web = w
        w.loadUrl("https://appassets.androidplatform.net/assets/engine.html")
    }

    fun send(cmd: String) {
        val w = web ?: return
        w.post { w.evaluateJavascript("sf(" + JSONObject.quote(cmd) + ")", null) }
    }

    fun stop() {
        val w = web ?: return
        web = null
        w.post {
            try { wm.removeView(w) } catch (e: Exception) { }
            w.destroy()
        }
    }

    private inner class Bridge {
        @JavascriptInterface
        fun line(s: String) {
            onLine(s)
        }
    }
}
