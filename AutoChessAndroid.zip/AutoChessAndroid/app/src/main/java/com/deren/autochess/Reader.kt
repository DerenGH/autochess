package com.deren.autochess

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Grayscale copy of a screen frame. */
class Gray(val w: Int, val h: Int) {
    val a = ByteArray(w * h)
    fun at(x: Int, y: Int): Int = a[y * w + x].toInt() and 0xFF
}

class BoardRect(var x0: Float, var y0: Float, var x1: Float, var y1: Float) {
    fun copy() = BoardRect(x0, y0, x1, y1)
}

class CellMap(val d: FloatArray, val frac: Float)

class ReadResult(
    val board: CharArray,       // 64 squares, a8 first, '.' = empty (absolute orientation)
    val whiteBottom: Boolean,
    val pieces: Int
)

object Reader {
    const val TN = 32
    const val PIECES = "PNBRQKpnbrqk"
    const val START = "rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR"

    private var tpl: Array<FloatArray> = emptyArray()     // normalised
    var raw: Array<FloatArray> = emptyArray()
    var hasTemplates = false

    // ---------- templates ----------
    private fun normalize(v: FloatArray): FloatArray {
        var m = 0f
        for (x in v) m += x
        m /= v.size
        val o = FloatArray(v.size)
        var s = 0f
        for (i in v.indices) { o[i] = v[i] - m; s += o[i] * o[i] }
        val n = sqrt(s).let { if (it == 0f) 1f else it }
        for (i in o.indices) o[i] /= n
        return o
    }

    fun setTemplates(r: Array<FloatArray>) {
        raw = r
        tpl = Array(12) { normalize(r[it]) }
        hasTemplates = true
    }

    /** bytes: 12 * 1024 signed bytes, each is value/2. */
    fun decode(bytes: ByteArray): Array<FloatArray> =
        Array(12) { k -> FloatArray(TN * TN) { i -> bytes[k * TN * TN + i].toInt() * 2f } }

    fun encode(r: Array<FloatArray>): ByteArray {
        val out = ByteArray(12 * TN * TN)
        for (k in 0 until 12) for (i in 0 until TN * TN)
            out[k * TN * TN + i] = (r[k][i] / 2f).roundToInt().coerceIn(-127, 127).toByte()
        return out
    }

    // ---------- per-square maps ----------
    fun cellMaps(g: Gray, r: BoardRect): Array<CellMap> {
        val bx0 = r.x0.roundToInt().coerceIn(0, g.w - 8)
        val by0 = r.y0.roundToInt().coerceIn(0, g.h - 8)
        val bx1 = r.x1.roundToInt().coerceIn(bx0 + 8, g.w)
        val by1 = r.y1.roundToInt().coerceIn(by0 + 8, g.h)
        val bw = bx1 - bx0
        val bh = by1 - by0
        return Array(64) { cellMap(g, bx0, by0, bw, bh, it shr 3, it and 7) }
    }

    private fun px(g: Gray, bx0: Int, by0: Int, x: Int, y: Int): Int {
        val gx = (bx0 + x).coerceIn(0, g.w - 1)
        val gy = (by0 + y).coerceIn(0, g.h - 1)
        return g.at(gx, gy)
    }

    private fun cellMap(g: Gray, bx0: Int, by0: Int, bw: Int, bh: Int, r: Int, c: Int): CellMap {
        val cw = bw / 8f
        val ch = bh / 8f
        val cx0 = c * cw
        val cy0 = r * ch
        val px0 = floor(cx0 + .80f * cw).toInt()
        val px1 = max(px0 + 1, ceil(cx0 + .96f * cw).toInt())
        val py0 = floor(cy0 + .03f * ch).toInt()
        val py1 = max(py0 + 1, ceil(cy0 + .12f * ch).toInt())
        val vals = ArrayList<Int>()
        for (y in py0 until py1) for (x in px0 until px1) vals.add(px(g, bx0, by0, x, y))
        vals.sort()
        val bg = vals[vals.size / 2].toFloat()
        val d = FloatArray(TN * TN)
        for (oy in 0 until TN) {
            val ys = floor(cy0 + oy * ch / TN).toInt()
            val ye = max(ys + 1, floor(cy0 + (oy + 1) * ch / TN).toInt())
            for (ox in 0 until TN) {
                val xs = floor(cx0 + ox * cw / TN).toInt()
                val xe = max(xs + 1, floor(cx0 + (ox + 1) * cw / TN).toInt())
                var s = 0L
                var n = 0
                for (y in ys until ye) for (x in xs until xe) { s += px(g, bx0, by0, x, y); n++ }
                d[oy * TN + ox] = (if (n > 0) s.toFloat() / n else bg) - bg
            }
        }
        var cnt = 0
        var tot = 0
        for (oy in 4..30) for (ox in 4..27) { tot++; if (abs(d[oy * TN + ox]) > 20f) cnt++ }
        return CellMap(d, cnt.toFloat() / tot)
    }

    // ---------- classification ----------
    class Cls(val ch: Char, val score: Float, val second: Float)

    fun classify(m: CellMap): Cls {
        val n = normalize(m.d)
        var best = -2f
        var second = -2f
        var bi = 0
        for (k in 0 until 12) {
            val t = tpl[k]
            var s = 0f
            for (i in n.indices) s += n[i] * t[i]
            if (s > best) { second = best; best = s; bi = k } else if (s > second) second = s
        }
        return Cls(PIECES[bi], best, second)
    }

    private fun centerMean(m: CellMap): Float {
        var s = 0f
        var n = 0
        for (oy in 6..28) for (ox in 8..24) { s += m.d[oy * TN + ox]; n++ }
        return s / n
    }

    /** Returns the position in absolute orientation, or null if templates are missing. */
    fun read(g: Gray, rect: BoardRect): ReadResult? {
        if (!hasTemplates) return null
        val maps = cellMaps(g, rect)
        val screen = CharArray(64) { '.' }
        for (i in 0 until 64) {
            val m = maps[i]
            if (m.frac < 0.06f) continue
            val c = classify(m)
            if (c.score >= 0.4f) screen[i] = c.ch
        }
        var wl = 0
        var wu = 0
        for (i in 0 until 64) {
            val ch = screen[i]
            if (ch != '.' && ch.isUpperCase()) { if ((i shr 3) >= 4) wl++ else wu++ }
        }
        val whiteBottom = wl >= wu
        val board = CharArray(64) { '.' }
        var n = 0
        for (i in 0 until 64) if (screen[i] != '.') {
            val row = i shr 3
            val col = i and 7
            val a = if (whiteBottom) i else (7 - row) * 8 + (7 - col)
            board[a] = screen[i]; n++
        }
        return ReadResult(board, whiteBottom, n)
    }

    /** Learn templates from a screenshot of the starting position. Returns an error text, or null on success. */
    fun learn(g: Gray, rect: BoardRect): String? {
        val maps = cellMaps(g, rect)
        fun rowMean(r: Int): Float { var s = 0f; for (c in 0 until 8) s += centerMean(maps[r * 8 + c]); return s / 8 }
        val wb = rowMean(7) > rowMean(0)
        val sum = Array(12) { FloatArray(TN * TN) }
        val cnt = IntArray(12)
        var bad = 0
        for (i in 0 until 64) {
            val r = i shr 3
            val c = i and 7
            val a = if (wb) i else (7 - r) * 8 + (7 - c)
            val e = START[a]
            if (e == '.') continue
            if (maps[i].frac < 0.04f) { bad++; continue }
            val k = PIECES.indexOf(e)
            for (j in 0 until TN * TN) sum[k][j] += maps[i].d[j]
            cnt[k]++
        }
        if (bad > 2 || cnt.any { it == 0 }) return "Not a fresh starting position"
        setTemplates(Array(12) { k -> FloatArray(TN * TN) { sum[k][it] / cnt[k] } })
        return null
    }

    // ---------- board finding ----------
    private class Small(val w: Int, val h: Int, val ii: DoubleArray, val f: Int)

    private fun small(g: Gray, f: Int): Small {
        val w = g.w / f
        val h = g.h / f
        val ii = DoubleArray((w + 1) * (h + 1))
        for (y in 0 until h) {
            var row = 0.0
            for (x in 0 until w) {
                var s = 0
                for (dy in 0 until f) for (dx in 0 until f) s += g.at(x * f + dx, y * f + dy)
                row += s.toDouble() / (f * f)
                ii[(y + 1) * (w + 1) + x + 1] = ii[y * (w + 1) + x + 1] + row
            }
        }
        return Small(w, h, ii, f)
    }

    private fun patchMean(s: Small, x0: Double, y0: Double, x1: Double, y1: Double): Double {
        val ax = floor(x0).toInt().coerceIn(0, s.w - 1)
        val ay = floor(y0).toInt().coerceIn(0, s.h - 1)
        val bx = max(ax + 1, ceil(x1).toInt().coerceAtMost(s.w))
        val by = max(ay + 1, ceil(y1).toInt().coerceAtMost(s.h))
        val w = s.w + 1
        val a = s.ii[ay * w + ax]
        val b = s.ii[ay * w + bx]
        val c = s.ii[by * w + ax]
        val d = s.ii[by * w + bx]
        return (d - b - c + a) / ((bx - ax) * (by - ay))
    }

    private fun checkScore(s: Small, x0: Double, y0: Double, size: Double): Double {
        val cell = size / 8
        val p = Array(8) { DoubleArray(8) }      // patch at the top-right of each cell
        val q = Array(8) { DoubleArray(8) }      // patch at the bottom-left of each cell
        var n0 = 0; var s0 = 0.0; var q0 = 0.0
        var n1 = 0; var s1 = 0.0; var q1 = 0.0
        for (r in 0 until 8) for (c in 0 until 8) {
            val cx = x0 + c * cell
            val cy = y0 + r * cell
            val v = patchMean(s, cx + .80 * cell, cy + .03 * cell, cx + .96 * cell, cy + .12 * cell)
            p[r][c] = v
            q[r][c] = patchMean(s, cx + .04 * cell, cy + .88 * cell, cx + .20 * cell, cy + .97 * cell)
            if (((r + c) and 1) == 1) { n1++; s1 += v; q1 += v * v } else { n0++; s0 += v; q0 += v * v }
        }
        val m0 = s0 / n0
        val m1 = s1 / n1
        val sd = sqrt(max(0.0, q0 / n0 - m0 * m0)) + sqrt(max(0.0, q1 / n1 - m1 * m1))
        val sign = if (m0 >= m1) 1.0 else -1.0
        // every row and column must alternate light/dark at both the top-right and bottom-left patch,
        // so a window shifted by one square (or cut through the board edge) scores about zero
        var worst = 1e9
        for (i in 0 until 8) {
            var re = 0.0; var ro = 0.0; var ce = 0.0; var co = 0.0
            var qre = 0.0; var qro = 0.0; var qce = 0.0; var qco = 0.0
            for (j in 0 until 8) {
                if (((i + j) and 1) == 0) { re += p[i][j]; ce += p[j][i]; qre += q[i][j]; qce += q[j][i] }
                else { ro += p[i][j]; co += p[j][i]; qro += q[i][j]; qco += q[j][i] }
            }
            worst = min(worst, sign * (re - ro) / 4)
            worst = min(worst, sign * (ce - co) / 4)
            worst = min(worst, sign * (qre - qro) / 4)
            worst = min(worst, sign * (qce - qco) / 4)
        }
        return worst - 0.6 * sd
    }

    /** Looks for an 8x8 checkerboard. Returns null when nothing convincing is found. */
    fun findBoard(g: Gray): BoardRect? {
        val f1 = max(1, g.w / 360)
        val a = small(g, f1)
        var bs = -1e18
        var bx = 0; var by = 0; var bsize = 0
        val minS = (min(a.w, a.h) * 0.5).toInt()
        val maxS = min(a.w, a.h)
        var s = maxS
        while (s >= minS) {
            var y = 0
            while (y + s <= a.h) {
                var x = 0
                while (x + s <= a.w) {
                    val sc = checkScore(a, x.toDouble(), y.toDouble(), s.toDouble())
                    if (sc > bs) { bs = sc; bx = x; by = y; bsize = s }
                    x += 3
                }
                y += 3
            }
            s -= 3
        }
        if (bs < -1e17) return null
        val b = small(g, 1)
        val k = f1.toDouble()
        val cs = bsize * k; val cx = bx * k; val cy = by * k
        var b2 = -1e18; var x2 = 0.0; var y2 = 0.0; var s2 = 0.0
        var ds = -8
        while (ds <= 8) {
            var dy = -8
            while (dy <= 8) {
                var dx = -8
                while (dx <= 8) {
                    val sz = cs + ds; val x = cx + dx; val y = cy + dy
                    if (x >= 0 && y >= 0 && x + sz <= b.w && y + sz <= b.h) {
                        val sc = checkScore(b, x, y, sz)
                        if (sc > b2) { b2 = sc; x2 = x; y2 = y; s2 = sz }
                    }
                    dx += 2
                }
                dy += 2
            }
            ds += 2
        }
        var b3 = b2; var x3 = x2; var y3 = y2; var s3 = s2
        for (dsz in -2..2) for (dy in -2..2) for (dx in -2..2) {
            val sz = s2 + dsz; val x = x2 + dx; val y = y2 + dy
            if (x >= 0 && y >= 0 && x + sz <= b.w && y + sz <= b.h) {
                val sc = checkScore(b, x, y, sz)
                if (sc > b3) { b3 = sc; x3 = x; y3 = y; s3 = sz }
            }
        }
        if (b3 < 8.0) return null
        return BoardRect(x3.toFloat(), y3.toFloat(), (x3 + s3).toFloat(), (y3 + s3).toFloat())
    }
}
