package com.deren.autochess

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.min

/**
 * Watches the screen, reads the chess board, asks Stockfish for the best move
 * and draws a frame around the two squares. Overlay only: it never touches the game.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_STOP = "com.deren.autochess.STOP"
        const val CHANNEL = "autochess"
        const val TAG = "AutoChess"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private lateinit var thread: HandlerThread
    private lateinit var bg: Handler

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var screenW = 0
    private var screenH = 0
    private var dpi = 0
    private var gray: Gray? = null

    private var engine: EngineHost? = null
    private var overlay: MoveOverlayView? = null
    private var panel: Panel? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var picker: View? = null

    // ---- state touched only on the bg thread ----
    private var rect: BoardRect? = null
    private var stable: CharArray? = null
    private var candidate: CharArray? = null
    private var candCount = 0
    private var castle = ""
    private var ep = "-"
    private var whiteBottom = true
    private var sideMode = 0           // 0 auto (bottom side), 1 white, 2 black
    private var paused = false
    private var pickerOpen = false
    private var engineReady = false
    private var gen = 0
    private var outstanding = 0
    private var running = false

    private val prefs by lazy { getSharedPreferences("ac", Context.MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        startForegroundNow()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (data == null) { shutdown(); return START_NOT_STICKY }
        try {
            setup(code, data)
        } catch (e: Throwable) {
            Log.e(TAG, "setup failed", e)
            Toast.makeText(this, "AutoChess could not start: " + e.message, Toast.LENGTH_LONG).show()
            shutdown()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "AutoChess overlay", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("AutoChess overlay is running")
            .setContentText("Tap Stop to end it")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_delete, "Stop", stopPi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun setup(code: Int, data: Intent) {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        thread = HandlerThread("ac-reader")
        thread.start()
        bg = Handler(thread.looper)

        val dm = DisplayMetrics()
        val disp = (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        @Suppress("DEPRECATION")
        disp.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        dpi = dm.densityDpi

        loadTemplates()
        rect = loadRect()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { shutdown() } }
        }, main)
        projection = p
        val ir = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        imageReader = ir
        vd = p.createVirtualDisplay(
            "autochess", screenW, screenH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.surface, null, null
        )

        // overlay that frames the suggested squares
        val ov = MoveOverlayView(this)
        ov.rect = rect
        wm.addView(ov, fullLp(false))
        overlay = ov

        // control panel
        val pn = Panel(this, object : Panel.Callbacks {
            override fun onBoard() { main.post { openPicker() } }
            override fun onLearn() { bg.post { learn() } }
            override fun onSide() { bg.post { cycleSide() } }
            override fun onNow() { bg.post { forceNow() } }
            override fun onPause() { bg.post { togglePause() } }
            override fun onStop() { main.post { shutdown() } }
            override fun onMoved(dx: Int, dy: Int) {
                val lp = panelLp ?: return
                lp.x += dx; lp.y += dy
                try { wm.updateViewLayout(panel, lp) } catch (e: Exception) { }
            }
        })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (8 * resources.displayMetrics.density).toInt()
        lp.y = (36 * resources.displayMetrics.density).toInt()
        wm.addView(pn, lp)
        panel = pn
        panelLp = lp

        // engine
        engine = EngineHost(this, wm, { line -> bg.post { onEngineLine(line) } }, { engine?.send("uci") }).also { it.start() }

        running = true
        status("Loading engine...")
        bg.postDelayed(tick, 800)
    }

    // ---------- helpers ----------
    private fun fullLp(touchable: Boolean): WindowManager.LayoutParams {
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        val lp = WindowManager.LayoutParams(
            screenW, screenH, 0, 0, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 30) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return lp
    }

    private fun status(t: String) {
        main.post { panel?.status?.text = t }
    }

    private fun toast(t: String) {
        main.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }
    }

    private fun loadTemplates() {
        try {
            val saved = prefs.getString("tpl", null)
            val b64 = saved ?: assets.open("tpl.b64").bufferedReader().readText().trim()
            Reader.setTemplates(Reader.decode(Base64.decode(b64, Base64.DEFAULT)))
        } catch (e: Throwable) {
            Log.e(TAG, "templates", e)
        }
    }

    private fun rectKey() = "rect_${screenW}x$screenH"

    private fun loadRect(): BoardRect? {
        val s = prefs.getString(rectKey(), null) ?: return null
        val p = s.split(",").mapNotNull { it.toFloatOrNull() }
        return if (p.size == 4) BoardRect(p[0], p[1], p[2], p[3]) else null
    }

    private fun saveRect(r: BoardRect) {
        prefs.edit().putString(rectKey(), "${r.x0},${r.y0},${r.x1},${r.y1}").apply()
    }

    private fun mySide(): Char = when (sideMode) { 1 -> 'w'; 2 -> 'b'; else -> if (whiteBottom) 'w' else 'b' }

    private fun showMove(from: Int, to: Int) {
        main.post {
            overlay?.let { it.from = from; it.to = to; it.flipped = !whiteBottom; it.rect = rect; it.invalidate() }
        }
    }

    private fun clearMove() = showMove(-1, -1)

    // ---------- capture loop (bg thread) ----------
    private val tick = object : Runnable {
        override fun run() {
            try { step() } catch (e: Throwable) { Log.e(TAG, "step", e) }
            if (running) bg.postDelayed(this, 700)
        }
    }

    private fun toGray(img: Image): Gray {
        val plane = img.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val ps = plane.pixelStride
        val w = img.width
        val h = img.height
        var g = gray
        if (g == null || g.w != w || g.h != h) { g = Gray(w, h); gray = g }
        val row = ByteArray(rs)
        for (y in 0 until h) {
            buf.position(y * rs)
            val len = min(rs, buf.remaining())
            buf.get(row, 0, len)
            var i = 0
            val o = y * w
            for (x in 0 until w) {
                if (i + 2 >= len) break
                val r = row[i].toInt() and 255
                val gg = row[i + 1].toInt() and 255
                val b = row[i + 2].toInt() and 255
                g.a[o + x] = ((299 * r + 587 * gg + 114 * b) / 1000).toByte()
                i += ps
            }
        }
        return g
    }

    private fun step() {
        if (paused || pickerOpen) return
        val img = imageReader?.acquireLatestImage() ?: return
        val g = try { toGray(img) } finally { img.close() }

        var r = rect
        if (r == null) {
            r = Reader.findBoard(g)
            if (r == null) { status("No board found. Open a game, or tap Board."); return }
            rect = r
            saveRect(r)
            main.post { overlay?.rect = r }
        }
        val res = Reader.read(g, r) ?: return
        if (!Chess.sane(res.board)) {
            candidate = null; candCount = 0
            if (stable != null) status("Waiting for a chess board...")
            return
        }
        whiteBottom = res.whiteBottom
        val cand = candidate
        if (cand != null && cand.contentEquals(res.board)) candCount++ else { candidate = res.board; candCount = 1 }
        val st = stable
        if (candCount >= 2 && (st == null || !st.contentEquals(res.board))) onNewPosition(res.board)
    }

    private fun onNewPosition(cur: CharArray) {
        val prev = stable
        val mv = if (prev != null) Chess.mover(prev, cur) else null
        val possible = Chess.castlingPossible(cur)
        castle = if (prev == null) possible else castle.filter { possible.contains(it) }
        ep = if (prev != null && mv != null) Chess.epTarget(prev, cur, mv) else "-"
        stable = cur
        val my = mySide()
        val stm: Char = when {
            mv != null -> if (mv == 'w') 'b' else 'w'
            String(cur) == Reader.START -> 'w'
            else -> my
        }
        if (stm == my) analyze(cur, stm) else {
            gen++
            clearMove()
            status("Opponent to move...")
        }
    }

    private fun forceNow() {
        val cur = stable ?: run { status("No position read yet."); return }
        analyze(cur, mySide())
    }

    private fun analyze(cur: CharArray, stmIn: Char) {
        var stm = stmIn
        if (Chess.wrongSide(cur, stm)) stm = if (stm == 'w') 'b' else 'w'
        val fen = Chess.fen(cur, stm, castle, ep)
        val e = engine
        if (e == null || !engineReady) { status("Engine not ready yet..."); return }
        gen++
        clearMove()
        status("Thinking...")
        if (outstanding > 0) e.send("stop")
        e.send("setoption name Skill Level value " + prefs.getInt("skill", 20))
        e.send("position fen $fen")
        e.send("go movetime " + prefs.getInt("time", 2000))
        outstanding++
    }

    private fun onEngineLine(line: String) {
        when {
            line == "uciok" -> { engine?.send("setoption name Hash value 32"); engine?.send("isready") }
            line == "readyok" -> { engineReady = true; status("Ready. Open your game."); }
            line.startsWith("bestmove") -> {
                if (outstanding > 0) outstanding--
                if (outstanding > 0) return
                val mv = line.split(" ").getOrNull(1) ?: return
                if (mv.length < 4 || mv == "(none)") { status("No legal move found."); return }
                val from = Chess.sqIdx(mv.substring(0, 2))
                val to = Chess.sqIdx(mv.substring(2, 4))
                showMove(from, to)
                status("Your move: ${mv.substring(0, 2)} → ${mv.substring(2, 4)}" + (if (mv.length > 4) " =" + mv[4].uppercaseChar() else ""))
            }
        }
    }

    // ---------- panel actions ----------
    private fun cycleSide() {
        sideMode = (sideMode + 1) % 3
        val label = when (sideMode) { 1 -> "Side: White"; 2 -> "Side: Black"; else -> "Side: Auto" }
        main.post { panel?.setSideLabel(label) }
        status("I play " + (if (mySide() == 'w') "White" else "Black") + ". Tap Now to refresh.")
    }

    private fun togglePause() {
        paused = !paused
        main.post { panel?.setPauseLabel(if (paused) "Resume" else "Pause") }
        if (paused) { gen++; clearMove(); status("Paused") } else { stable = null; candidate = null; status("Watching...") }
    }

    private fun learn() {
        val r = rect
        val g = gray
        if (r == null || g == null) { toast("No board yet. Open a new game first."); return }
        val err = Reader.learn(g, r)
        if (err != null) { toast("Learn failed: $err. Start a new game and try again."); return }
        prefs.edit().putString("tpl", Base64.encodeToString(Reader.encode(Reader.raw), Base64.NO_WRAP)).apply()
        stable = null; candidate = null
        toast("Learned your piece style.")
    }

    private fun openPicker() {
        if (picker != null) return
        pickerOpen = true
        val start = rect?.copy() ?: bg2()
        val v = CornerPicker(this, start, { done ->
            bg.post {
                rect = done
                saveRect(done)
                stable = null; candidate = null; candCount = 0
                main.post { overlay?.rect = done; closePicker() }
                pickerOpen = false
            }
        }, { gray?.let { Reader.findBoard(it) } })
        picker = v
        wm.addView(v, fullLp(true))
    }

    private fun bg2(): BoardRect {
        val s = screenW.toFloat()
        val top = (screenH - s) / 2f
        return BoardRect(0f, top, s, top + s)
    }

    private fun closePicker() {
        picker?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        picker = null
    }

    // ---------- shutdown ----------
    private fun shutdown() {
        running = false
        try { if (::bg.isInitialized) bg.removeCallbacksAndMessages(null) } catch (e: Exception) { }
        closePicker()
        overlay?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        overlay = null
        panel = null
        engine?.stop()
        engine = null
        try { vd?.release() } catch (e: Exception) { }
        try { imageReader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        vd = null; imageReader = null; projection = null
        if (::thread.isInitialized) thread.quitSafely()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) shutdown()
        super.onDestroy()
    }
}
