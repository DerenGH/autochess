package com.deren.autochess

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot

/** Draws a frame around the two squares of the suggested move. Never intercepts touches. */
class MoveOverlayView(ctx: Context) : View(ctx) {
    var rect: BoardRect? = null
    var flipped = false
    var from = -1
    var to = -1

    private val pFrom = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.rgb(255, 160, 0) }
    private val pTo = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.rgb(0, 230, 118) }

    override fun onDraw(c: Canvas) {
        val r = rect ?: return
        if (from < 0 || to < 0) return
        val cw = (r.x1 - r.x0) / 8f
        val ch = (r.y1 - r.y0) / 8f
        drawFrame(c, from, pFrom, r, cw, ch)
        drawFrame(c, to, pTo, r, cw, ch)
    }

    private fun drawFrame(c: Canvas, idx: Int, p: Paint, r: BoardRect, cw: Float, ch: Float) {
        var row = idx shr 3
        var col = idx and 7
        if (flipped) { row = 7 - row; col = 7 - col }
        val l = r.x0 + col * cw
        val t = r.y0 + row * ch
        p.strokeWidth = cw * 0.05f
        val i = p.strokeWidth / 2f
        c.drawRect(l + i, t + i, l + cw - i, t + ch - i, p)
    }
}

/** Small floating control panel. */
class Panel(ctx: Context, private val cb: Callbacks) : LinearLayout(ctx) {
    interface Callbacks {
        fun onBoard()
        fun onLearn()
        fun onSide()
        fun onNow()
        fun onPause()
        fun onStop()
        fun onMoved(dx: Int, dy: Int)
    }

    val status = TextView(ctx)
    private val sideBtn: Button
    private val pauseBtn: Button
    private val rows = LinearLayout(ctx)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    init {
        orientation = VERTICAL
        setBackgroundColor(Color.argb(210, 20, 24, 30))
        setPadding(dp(6), dp(4), dp(6), dp(6))
        status.setTextColor(Color.WHITE)
        status.textSize = 13f
        status.typeface = Typeface.MONOSPACE
        status.setPadding(dp(4), dp(4), dp(4), dp(4))
        status.text = "AutoChess starting..."
        addView(status, LayoutParams(dp(210), LayoutParams.WRAP_CONTENT))

        rows.orientation = VERTICAL
        val r1 = LinearLayout(ctx)
        val r2 = LinearLayout(ctx)
        fun b(t: String, f: () -> Unit): Button {
            val x = Button(ctx)
            x.text = t
            x.textSize = 11f
            x.isAllCaps = false
            x.minWidth = 0
            x.minimumWidth = 0
            x.minHeight = 0
            x.minimumHeight = 0
            x.setPadding(dp(4), dp(6), dp(4), dp(6))
            x.setOnClickListener { f() }
            return x
        }
        val lp = { LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f) }
        r1.addView(b("Board") { cb.onBoard() }, lp())
        r1.addView(b("Learn") { cb.onLearn() }, lp())
        sideBtn = b("Side: Auto") { cb.onSide() }
        r1.addView(sideBtn, lp())
        r2.addView(b("Now") { cb.onNow() }, lp())
        pauseBtn = b("Pause") { cb.onPause() }
        r2.addView(pauseBtn, lp())
        r2.addView(b("Stop") { cb.onStop() }, lp())
        rows.addView(r1)
        rows.addView(r2)
        addView(rows)

        // drag by the status line, tap it to fold the buttons away
        var downX = 0f
        var downY = 0f
        var lastX = 0f
        var lastY = 0f
        var moved = false
        status.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; lastX = downX; lastY = downY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (hypot(e.rawX - downX, e.rawY - downY) > dp(8)) moved = true
                    if (moved) { cb.onMoved((e.rawX - lastX).toInt(), (e.rawY - lastY).toInt()) }
                    lastX = e.rawX; lastY = e.rawY
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) rows.visibility = if (rows.visibility == VISIBLE) GONE else VISIBLE
                }
            }
            true
        }
    }

    fun setSideLabel(t: String) { sideBtn.text = t }
    fun setPauseLabel(t: String) { pauseBtn.text = t }
}

/** Full-screen helper for placing the two board corners. */
class CornerPicker(ctx: Context, start: BoardRect, private val onDone: (BoardRect) -> Unit, private val onAuto: () -> BoardRect?) : FrameLayout(ctx) {
    private val r = start.copy()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(56, 200, 245); style = Paint.Style.STROKE; strokeWidth = 2f }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(56, 200, 245); style = Paint.Style.STROKE; strokeWidth = 5f }
    private var active = 0          // 1 = top-left, 2 = bottom-right
    private var offX = 0f
    private var offY = 0f

    private fun dp(v: Int) = (v * resources.displayMetrics.density)

    private val canvasView = object : View(ctx) {
        override fun onDraw(c: Canvas) {
            for (i in 0..8) {
                val x = r.x0 + (r.x1 - r.x0) * i / 8f
                val y = r.y0 + (r.y1 - r.y0) * i / 8f
                c.drawLine(x, r.y0, x, r.y1, line)
                c.drawLine(r.x0, y, r.x1, y, line)
            }
            val rad = dp(16)
            for (p in listOf(Pair(r.x0, r.y0), Pair(r.x1, r.y1))) {
                c.drawCircle(p.first, p.second, rad, dot)
                c.drawLine(p.first - rad * 1.8f, p.second, p.first + rad * 1.8f, p.second, dot)
                c.drawLine(p.first, p.second - rad * 1.8f, p.first, p.second + rad * 1.8f, dot)
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val d1 = hypot(e.x - r.x0, e.y - r.y0)
                    val d2 = hypot(e.x - r.x1, e.y - r.y1)
                    val reach = dp(110)
                    active = when { d1 <= d2 && d1 < reach -> 1; d2 < d1 && d2 < reach -> 2; else -> 0 }
                    if (active == 1) { offX = e.x - r.x0; offY = e.y - r.y0 }
                    if (active == 2) { offX = e.x - r.x1; offY = e.y - r.y1 }
                }
                MotionEvent.ACTION_MOVE -> {
                    val min = dp(80)
                    if (active == 1) {
                        r.x0 = (e.x - offX).coerceIn(0f, r.x1 - min)
                        r.y0 = (e.y - offY).coerceIn(0f, r.y1 - min)
                    } else if (active == 2) {
                        r.x1 = (e.x - offX).coerceIn(r.x0 + min, width.toFloat())
                        r.y1 = (e.y - offY).coerceIn(r.y0 + min, height.toFloat())
                    }
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> active = 0
            }
            return true
        }
    }

    init {
        addView(canvasView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        val hint = TextView(ctx)
        hint.text = "Drag the two rings onto the top-left and bottom-right corners of the board. You can grab them from a little way off."
        hint.setTextColor(Color.WHITE)
        hint.textSize = 13f
        hint.setBackgroundColor(Color.argb(200, 20, 24, 30))
        hint.setPadding(dp(10).toInt(), dp(8).toInt(), dp(10).toInt(), dp(8).toInt())
        addView(hint, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.TOP })

        val bar = LinearLayout(ctx)
        val auto = Button(ctx)
        auto.text = "Find automatically"
        auto.setOnClickListener {
            val f = onAuto()
            if (f != null) { r.x0 = f.x0; r.y0 = f.y0; r.x1 = f.x1; r.y1 = f.y1; canvasView.invalidate() }
        }
        val done = Button(ctx)
        done.text = "Done"
        done.setOnClickListener { onDone(r.copy()) }
        bar.addView(auto, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(done, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(bar, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM
            bottomMargin = dp(90).toInt()
        })
    }
}
