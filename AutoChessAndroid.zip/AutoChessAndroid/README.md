# AutoChess for Android (overlay only)

Reads the chess board from your screen, asks Stockfish 18 for the best move and draws two frames
on top of the game: orange = piece to move, green = where it goes. It never taps anything.

## Get the APK (no Android Studio needed)

1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab, pick **Build APK**, tap **Run workflow**. (It also runs on every push.)
3. When it turns green, open the run and download the **AutoChess-apk** artifact. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone, open it and allow "install unknown apps" when asked.

Or open the folder in Android Studio and press Run.

## Use it

1. Open AutoChess, tap **Start**. First time only: allow "Display over other apps".
2. In the screen-capture dialog choose **Entire screen** (Android 14+ also offers "A single app": pick your chess app).
3. Open your chess game. A small panel appears at the top of the screen.
4. When it is your move, the two frames show up. When the opponent moves, they clear and it thinks again.

Panel buttons (tap the status line to fold them, drag it to move the panel):

| Button | What it does |
| --- | --- |
| Board | Drag two rings onto the top-left and bottom-right corners of the board. Needed only if the frames are misplaced. |
| Learn | Teach it your piece style. Start a fresh game (starting position on screen), then tap it. |
| Side | Auto = you play the side at the bottom. Force White or Black if needed. |
| Now | Ask for a move for the current position right now. |
| Pause / Resume | Stop watching the screen. |
| Stop | Close the overlay. |

Strength and thinking time are set on the first screen.

## Notes

* The built-in piece reader knows the Chess.com gray piece set. Other sets: use **Learn** once.
* Move detection works by comparing screenshots, so it needs to see each position for about a second.
* The engine is the single-thread WebAssembly build of Stockfish 18 (GPLv3), running in a hidden WebView.
